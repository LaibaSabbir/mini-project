﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FYP_mini
{
    public partial class Group : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DELL-PC\\SABBER;Initial Catalog=ProjectA;Integrated Security=True");

        public Group()
        {
            InitializeComponent();
            
            conn.Open();
            string datacmd = "SELECT Value from Lookup WHERE Category='STATUS' ";
            SqlCommand cmmd = new SqlCommand(datacmd, conn);
            SqlDataAdapter dataadap = new SqlDataAdapter(datacmd, conn);
            DataTable dataset = new DataTable();
            dataadap.Fill(dataset);

            for (int i = 0; i < dataset.Rows.Count; i++)
            {
                comboBox2.Items.Add(dataset.Rows[i]["Value"]);
            }
            cmmd.ExecuteNonQuery();


            string datacmd1 = "SELECT RegistrationNo from Student " +
                "WHERE Student.Id NOT IN (SELECT StudentId FROM GroupStudent)";
            
            SqlCommand cmmd1 = new SqlCommand(datacmd1, conn);
            SqlDataAdapter dataadap1 = new SqlDataAdapter(datacmd1, conn);
            DataTable dataset1 = new DataTable();
            dataadap1.Fill(dataset1);

            for (int i = 0; i < dataset1.Rows.Count; i++)
            {
                comboBox1.Items.Add(dataset1.Rows[i]["RegistrationNo"]);
            }
            cmmd1.ExecuteNonQuery();
            data_load();
            conn.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void Group_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortDateString();
            labeldate.Text = DateTime.Now.ToShortDateString();
            conn.Open();
            data_load();
           // Console.WriteLine("hello");

            var DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.Name = "DeleteButton";
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Text = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(DeleteButton);

            conn.Close();
        }
        private void data_load()
        {
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT StudentId,Status,AssignmentDate FROM  [ProjectA].[dbo].[GroupStudent] ", conn);
            DataTable dtbl = new DataTable(); 
            sqlDa.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonadd_Click(object sender, EventArgs e)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            DateTime daate = DateTime.Now.Date;
            string gpinsert = string.Format("INSERT INTO [ProjectA].[dbo].[Group] (Created_On) VALUES (@datte)");
            SqlCommand gpcom = new SqlCommand(gpinsert, conn);
            gpcom.Parameters.AddWithValue("@datte", daate);
            gpcom.ExecuteNonQuery();
            gpcom.Parameters.Clear();

            string gpselect = string.Format("SELECT TOP 1 Id FROM [ProjectA].[dbo].[Group] GROUP BY Id " +
                "ORDER BY Id desc");
            SqlCommand gpcomm = new SqlCommand(gpselect, conn);
            int id = Convert.ToInt32(gpcomm.ExecuteScalar());

            string Stat;
            Stat = string.Format("SELECT Id FROM Lookup WHERE Category='STATUS' AND Value='{0}'", comboBox2.Text);
            SqlCommand comm1 = new SqlCommand(Stat, conn);
            int statusval = Convert.ToInt32(comm1.ExecuteScalar());

            string stid;
            stid = string.Format("SELECT Id FROM Student WHERE RegistrationNo='{0}'", comboBox1.Text);
            SqlCommand commd2 = new SqlCommand(stid, conn);
            int stuid = Convert.ToInt32(commd2.ExecuteScalar());

            string gselect = ("INSERT INTO [ProjectA].[dbo].[GroupStudent] (GroupId,StudentId,Status,AssignmentDate) VALUES (@gpid,@stid,@status,@ad)");
            SqlCommand gscom = new SqlCommand(gselect, conn);
            gscom.Parameters.AddWithValue("@gpid", id);
            gscom.Parameters.AddWithValue("@stid", stuid);
            gscom.Parameters.AddWithValue("@status", statusval);
            gscom.Parameters.AddWithValue("@ad", daate);
            gscom.ExecuteNonQuery();
            gscom.Parameters.Clear();
            MessageBox.Show("group added");
            data_load();

            conn.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();
            if (e.ColumnIndex == 3)
            {
                if (MessageBox.Show("Are You Sure to Delete this Record ?", "Group", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;

                    string data = _dgvCurrentRow.Cells[0].Value.ToString();

                    string cmd = string.Format("SELECT GroupId FROM GroupStudent Where StudentId ='{0}'", data);
                    SqlCommand commd = new SqlCommand(cmd, conn);
                    int id = Convert.ToInt32(commd.ExecuteScalar());
                    //Console.WriteLine(id);
                    string queryy1 = string.Format("Delete from GroupStudent where GroupId='{0}'", id);
                    SqlCommand comd1 = new SqlCommand(queryy1, conn);
                    comd1.ExecuteNonQuery();
                    string queryy4 = string.Format("Delete from Group where Id='{0}'", id);
                    SqlCommand comd4 = new SqlCommand(queryy4, conn);
                    comd4.ExecuteNonQuery();
                    MessageBox.Show("Group deleted");
                    data_load();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                    return;
                }
            }
            else
            {
                conn.Close();
            }
        }
    }
}
