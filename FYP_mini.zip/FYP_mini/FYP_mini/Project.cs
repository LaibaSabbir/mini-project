﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace FYP_mini
{
    public partial class Project : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DELL-PC\\SABBER;Initial Catalog=ProjectA;Integrated Security=True");
        int getid;
        public Project()
        {
            InitializeComponent();
            buttonupdate.Hide();
        }

        private void Project_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortDateString();
            label5.Text = DateTime.Now.ToShortDateString();
            conn.Open();
            data_load();
            var EditButton = new DataGridViewButtonColumn();
            EditButton.Name = "EditButton";
            EditButton.HeaderText = "Edit";
            EditButton.Text = "Edit";
            EditButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(EditButton);

            var DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.Name = "DeleteButton";
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Text = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(DeleteButton);

            conn.Close();
        }

        private void data_load()
        {
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Title,Description FROM [ProjectA].[dbo].[Project]", conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;
        }
        private void buttonadd_Click(object sender, EventArgs e)
        {
           
        }

        private void buttonadd_Click_1(object sender, EventArgs e)
        {
            conn.Open();

            if (txtname.Text.Trim() == "" && txtdesc.Text.Trim() == "")
            {
                MessageBox.Show("All fields are required ");
                conn.Close();
                return;
            }


            string insertt = string.Format("INSERT INTO [ProjectA].[dbo].[Project](Title,Description)VALUES (@name,@description)");
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@name", txtname.Text);
            comm2.Parameters.AddWithValue("@description", txtdesc.Text);

            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            MessageBox.Show("Project information added");
            dataGridView1.Update();
            conn.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            

            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();
            if (e.ColumnIndex == 3)
            {
                if (MessageBox.Show("Are You Sure to Delete this Record ?", "Project", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;

                    string data = _dgvCurrentRow.Cells[0].Value.ToString();

                    string cmd = string.Format("SELECT Id FROM Project Where Title ='{0}'", data);
                    SqlCommand commd = new SqlCommand(cmd, conn);
                    int id = Convert.ToInt32(commd.ExecuteScalar());
                    Console.WriteLine(id);
                    string queryy1 = string.Format("Delete from Project where Id='{0}'", id);
                    SqlCommand comd1 = new SqlCommand(queryy1, conn);
                    comd1.ExecuteNonQuery();

                    MessageBox.Show("Project deleted");
                    data_load();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                    return;
                }
            }
            else if (e.ColumnIndex == 2)
            {
                DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;
                string data = _dgvCurrentRow.Cells[0].Value.ToString();
                string cmd = string.Format("SELECT Id FROM Project Where Title ='{0}'", data);
                SqlCommand commd = new SqlCommand(cmd, conn);
                getid = Convert.ToInt32(commd.ExecuteScalar());
                txtname.Text = _dgvCurrentRow.Cells[0].Value.ToString();
                txtdesc.Text = _dgvCurrentRow.Cells[1].Value.ToString();

                buttonadd.Hide();
                buttonupdate.Show();
                tabPage1.Show();
                conn.Close();
            }
            
            else
            {
                conn.Close();
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            conn.Open();
            if (txtname.Text.Trim() == "" && txtdesc.Text.Trim() == "" )
            {
                MessageBox.Show("All fields are required ");
                conn.Close();
                return;
            }

            Console.WriteLine(getid);
            string insertt = string.Format("UPDATE [dbo].[Evaluation] SET Title = @name ,Description= @desc  WHERE Id = '{0}'", getid);
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@name", txtname.Text);
            comm2.Parameters.AddWithValue("@desc", txtdesc.Text);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            MessageBox.Show("Project information updated");
            data_load();
            tabPage2.Show();
            conn.Close();
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
