﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace FYP_mini
{
    public partial class Student : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DELL-PC\\SABBER;Initial Catalog=ProjectA;Integrated Security=True");
        int getid;
        public Student()
        {
            InitializeComponent();
            buttonupdate.Hide();
        }

        private void Student_Load(object sender, EventArgs e)
        {
            conn.Open();
            label3.Text = DateTime.Now.ToShortDateString();
            label5.Text = DateTime.Now.ToShortDateString();
            data_load();
            var EditButton = new DataGridViewButtonColumn();
            EditButton.Name = "EditButton";
            EditButton.HeaderText = "Edit";
            EditButton.Text = "Edit";
            EditButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(EditButton);

            var DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.Name = "DeleteButton";
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Text = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(DeleteButton);
            conn.Close();
        }
        private void data_load()
        {
            
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT FirstName,RegistrationNo,LastName,Contact,Email,DateOfBirth,Value FROM ([ProjectA].[dbo].[Student] JOIN [ProjectA].[dbo].[Person] ON (Person.id=Student.id))JOIN [ProjectA].[dbo].[Lookup] ON (GENDER=Lookup.id)", conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cmbgender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonadd_Click(object sender, EventArgs e)
        {
            conn.Open();
            string Gender;
            Gender = string.Format("SELECT Id FROM Lookup WHERE Category='GENDER' AND Value='{0}'", cmbgender.Text);
            SqlCommand comm1 = new SqlCommand(Gender, conn);
            int genderval = Convert.ToInt32(comm1.ExecuteScalar());

            Console.WriteLine("GENDER" + genderval);
            Console.ReadLine();

            if (txtfirstname.Text.Trim() == "" && txtlastname.Text.Trim() == "" && txtemail.Text.Trim() == "" && txtregno.Text.Trim() == "" && txtnum.Text.Trim() == "" )
            {
                MessageBox.Show("ALL FIELDS are required");
                conn.Close();
                return;
            }
            string insertt = string.Format("INSERT INTO [ProjectA].[dbo].[Person](FirstName,[LastName],[Contact],[Email],[DateOfBirth],[Gender])VALUES (@Firstname,@Lastname,@Contactno,@Email,@Dateofbirth,@Gender)");
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@Firstname", txtfirstname.Text);
            comm2.Parameters.AddWithValue("@Lastname", txtlastname.Text);
            comm2.Parameters.AddWithValue("@Contactno", txtnum.Text);
            comm2.Parameters.AddWithValue("@Email", txtemail.Text);
            comm2.Parameters.AddWithValue("@Dateofbirth", dateTimePicker1.Value);
            comm2.Parameters.AddWithValue("@Gender", genderval);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            string personid = string.Format("SELECT Id FROM [ProjectA].[dbo].[Person] WHERE Email = '{0}'", txtemail.Text);
            SqlCommand comm3 = new SqlCommand(personid, conn);
            int id = Convert.ToInt32(comm3.ExecuteScalar());
            string insertstudent = string.Format("INSERT INTO [ProjectA].[dbo].[Student]([Id],[RegistrationNo]) VALUES (@id,@regno)");
            SqlCommand comm4 = new SqlCommand(insertstudent, conn);
            comm4.Parameters.AddWithValue("@id", id);
            comm4.Parameters.AddWithValue("@regno", txtregno.Text);
            comm4.ExecuteNonQuery();
            comm4.Parameters.Clear();
            MessageBox.Show("student added");
            data_load();
            conn.Close();
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
           
        }

        private void VIEW_STUDENT_Click(object sender, EventArgs e)
        {
            
        }

        private void tableLayoutPanel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void lastname_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void txtfirstname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtlastname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtnum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }


        private void EditButton_Click(object sender, MouseEventArgs e)
        {
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();
            if (e.ColumnIndex == 8)
            {
                if (MessageBox.Show("Are You Sure to Delete this Record ?", "Student", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;

                    string data = _dgvCurrentRow.Cells[5].Value.ToString();

                    string cmd = string.Format("SELECT Id FROM Person Where Email='{0}'", data);
                    SqlCommand commd = new SqlCommand(cmd, conn);
                    int id = Convert.ToInt32(commd.ExecuteScalar());
                    Console.WriteLine(id);
                    string queryy1 = string.Format("Delete from Student where Student.Id='{0}'", id);
                    SqlCommand comd1 = new SqlCommand(queryy1, conn);
                    comd1.ExecuteNonQuery();

                    string queryy = string.Format("Delete from Person where Id = '{0}'", id);
                    SqlCommand comd = new SqlCommand(queryy, conn);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("student deleted");
                    data_load();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                    return;
                }
            }
            else if(e.ColumnIndex == 7)
            {
                DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;
                string data = _dgvCurrentRow.Cells[5].Value.ToString();
                string cmd = string.Format("SELECT Id FROM Person Where Email ='{0}'", data);
                SqlCommand commd = new SqlCommand(cmd, conn);
                getid = Convert.ToInt32(commd.ExecuteScalar());
                txtfirstname.Text = _dgvCurrentRow.Cells[0].Value.ToString();
                txtlastname.Text = _dgvCurrentRow.Cells[1].Value.ToString();
                txtnum.Text = _dgvCurrentRow.Cells[4].Value.ToString();
                txtregno.Text = _dgvCurrentRow.Cells[2].Value.ToString();
                cmbgender.Text = _dgvCurrentRow.Cells[3].Value.ToString();
                txtemail.Text = _dgvCurrentRow.Cells[5].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(_dgvCurrentRow.Cells[6].ToString());
                //cmbgender.SelectedValue = Convert.ToInt32(dr["PositionID"].ToString());
                buttonadd.Hide();
                buttonupdate.Show();
                tabPage2.Show();
            }
            else
            {
                conn.Close();
            }


        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            conn.Open();
            string Gender;
            Gender = string.Format("SELECT Id FROM Lookup WHERE Category='GENDER' AND Value='{0}'", cmbgender.Text);
            SqlCommand comm1 = new SqlCommand(Gender, conn);
            int genderval = Convert.ToInt32(comm1.ExecuteScalar());

            Console.WriteLine("GENDER" + genderval);
            Console.ReadLine();

            if (txtfirstname.Text.Trim() == "" && txtlastname.Text.Trim() == "" && txtemail.Text.Trim() == "" && txtregno.Text.Trim() == "" && txtnum.Text.Trim() == "")
            {
                MessageBox.Show("ALL FIELDS are required");
                conn.Close();
                return;
            }
            string insertt = string.Format("Update [ProjectA].[dbo].[Person] SET FirstName=@Firstname,LastName=@Lastname,Contact=@Contactno,[Email] =@Email ,[DateOfBirth]=@Dateofbirth,[Gender]=@Gender WHERE Id = '{0}'", getid);
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@Firstname", txtfirstname.Text);
            comm2.Parameters.AddWithValue("@Lastname", txtlastname.Text);
            comm2.Parameters.AddWithValue("@Contactno", txtnum.Text);
            comm2.Parameters.AddWithValue("@Email", txtemail.Text);
            comm2.Parameters.AddWithValue("@Dateofbirth", dateTimePicker1.Value);
            comm2.Parameters.AddWithValue("@Gender", genderval);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();
            
            string insertstudent = string.Format("Update [ProjectA].[dbo].[Student] SET [RegistrationNo]=@regno)WHERE Id = '{0}'", getid);
            SqlCommand comm4 = new SqlCommand(insertstudent, conn);
            
            comm4.Parameters.AddWithValue("@regno", txtregno.Text);
            comm4.ExecuteNonQuery();
            comm4.Parameters.Clear();
            MessageBox.Show("student updated");
            data_load();
            conn.Close();
        
        }
    }

}
