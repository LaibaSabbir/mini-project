﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace FYP_mini
{
    public partial class Advisor : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DELL-PC\\SABBER;Initial Catalog=ProjectA;Integrated Security=True");
        int getid;
        public Advisor()
        {
            InitializeComponent();
            buttonupdate.Hide();
            conn.Open();
            string datacmd = "SELECT Value from Lookup WHERE Category='DESIGNATION' ";
            SqlCommand cmmd = new SqlCommand(datacmd, conn);
            SqlDataAdapter dataadap = new SqlDataAdapter(datacmd, conn);
            DataTable dataset = new DataTable();
            dataadap.Fill(dataset);
            
            for(int i=0;i<dataset.Rows.Count;i++)
            {
                comboBox1.Items.Add(dataset.Rows[i]["Value"]);
            }
            cmmd.ExecuteNonQuery();
            conn.Close();
        }

        private void Advisor_Load(object sender, EventArgs e)
        {

            label5.Text = DateTime.Now.ToShortDateString();
            labeldate.Text = DateTime.Now.ToShortDateString();
            conn.Open();
            data_load();
              var EditButton = new DataGridViewButtonColumn();
                EditButton.Name = "EditButton";
                EditButton.HeaderText = "Edit";
                EditButton.Text = "Edit";
                EditButton.UseColumnTextForButtonValue = true;
                this.dataGridView1.Columns.Add(EditButton);

                var DeleteButton = new DataGridViewButtonColumn();
                DeleteButton.Name = "DeleteButton";
                DeleteButton.HeaderText = "Delete";
                DeleteButton.Text = "Delete";
                DeleteButton.UseColumnTextForButtonValue = true;
                this.dataGridView1.Columns.Add(DeleteButton);
            
            conn.Close();
        }
        private void data_load()
        {
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT FirstName,Value,Salary,LastName,Contact,Email,DateOfBirth,Designation FROM ([ProjectA].[dbo].[Advisor] JOIN [ProjectA].[dbo].[Person] ON (Person.id=  Advisor.id))JOIN [ProjectA].[dbo].[Lookup] ON (GENDER=Lookup.id)", conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;
        }
        private void buttonadd_Click(object sender, EventArgs e)
        {
            
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void regno_Click(object sender, EventArgs e)
        {

        }

        private void email_Click(object sender, EventArgs e)
        {

        }

        private void gender_Click(object sender, EventArgs e)
        {

        }

        private void DOB_Click(object sender, EventArgs e)
        {

        }

        private void ContactNo_Click(object sender, EventArgs e)
        {

        }

        private void txtfirstname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtlastname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtregno_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtemail_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbgender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtnum_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void lastname_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonadd_Click_1(object sender, EventArgs e)
        {
            if (conn.State != ConnectionState.Open )
            {
                conn.Open();
            }
            string Gender;
            Gender = string.Format("SELECT Id FROM Lookup WHERE Category='GENDER' AND Value='{0}'", cmbgender.Text);
            SqlCommand comm1 = new SqlCommand(Gender, conn);
            int genderval = Convert.ToInt32(comm1.ExecuteScalar());
            string Designation;
            Designation = string.Format("SELECT Id FROM Lookup WHERE Category='DESIGNATION' AND Value='{0}'", comboBox1.Text);
            SqlCommand commd2 = new SqlCommand(Designation, conn);
            int desigval = Convert.ToInt32(commd2.ExecuteScalar());


            if (txtfirstname.Text.Trim() == "" && txtlastname.Text.Trim() == "" && txtemail.Text.Trim() == ""  && txtsalary.Text.Trim() == "" && txtnum.Text.Trim() == "")
            {
                MessageBox.Show("All fields are required ");
                conn.Close();
                return;
            }
            string insertt = string.Format("INSERT INTO [ProjectA].[dbo].[Person](FirstName,[LastName],[Contact],[Email],[DateOfBirth],[Gender])VALUES (@Firstname,@Lastname,@Contactno,@Email,@Dateofbirth,@Gender)");
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@Firstname", txtfirstname.Text);
            comm2.Parameters.AddWithValue("@Lastname", txtlastname.Text);
            comm2.Parameters.AddWithValue("@Contactno", txtnum.Text);
            comm2.Parameters.AddWithValue("@Email", txtemail.Text);
            comm2.Parameters.AddWithValue("@Dateofbirth", dateTimePicker1.Value);
            comm2.Parameters.AddWithValue("@Gender", genderval);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            string personid = string.Format("SELECT Id FROM [ProjectA].[dbo].[Person] WHERE Email = '{0}'", txtemail.Text);
            SqlCommand comm3 = new SqlCommand(personid, conn);
            int id = Convert.ToInt32(comm3.ExecuteScalar());
            string insertstudent = string.Format("INSERT INTO [ProjectA].[dbo].[Advisor]([Id],[Designation],[Salary]) VALUES (@id,@regno,@salary)");
            SqlCommand comm4 = new SqlCommand(insertstudent, conn);
            comm4.Parameters.AddWithValue("@id", id);
            comm4.Parameters.AddWithValue("@regno", desigval);
            comm4.Parameters.AddWithValue("@salary", txtsalary.Text);
            comm4.ExecuteNonQuery();
            comm4.Parameters.Clear();
            MessageBox.Show("Advisor added");
            data_load();
            conn.Close();
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            string Gender;
            Gender = string.Format("SELECT Id FROM Lookup WHERE Category='GENDER' AND Value='{0}'", cmbgender.Text);
            SqlCommand comm1 = new SqlCommand(Gender, conn);
            int genderval = Convert.ToInt32(comm1.ExecuteScalar());
            string Designation;
            Designation = string.Format("SELECT Id FROM Lookup WHERE Category='DESIGNATION' AND Value='{0}'", comboBox1.Text);
            SqlCommand commd2 = new SqlCommand(Designation, conn);
            int desigval = Convert.ToInt32(commd2.ExecuteScalar());


            if (txtfirstname.Text.Trim() == "" && txtlastname.Text.Trim() == "" && txtemail.Text.Trim() == "" && txtsalary.Text.Trim() == "" && txtnum.Text.Trim() == "")
            {
                MessageBox.Show("All fields are required ");
                conn.Close();
                return;
            }
            string insertt = string.Format("Update [ProjectA].[dbo].[Person] SET FirstName=@Firstname,LastName=@Lastname,Contact=@Contactno,[Email] =@Email ,[DateOfBirth]=@Dateofbirth,[Gender]=@Gender WHERE Id = '{0}'", getid);
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@Firstname", txtfirstname.Text);
            comm2.Parameters.AddWithValue("@Lastname", txtlastname.Text);
            comm2.Parameters.AddWithValue("@Contactno", txtnum.Text);
            comm2.Parameters.AddWithValue("@Email", txtemail.Text);
            comm2.Parameters.AddWithValue("@Dateofbirth", dateTimePicker1.Value);
            comm2.Parameters.AddWithValue("@Gender", genderval);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            string personid = string.Format("SELECT Id FROM [ProjectA].[dbo].[Person] WHERE Email = '{0}'", txtemail.Text);
            SqlCommand comm3 = new SqlCommand(personid, conn);
            int id = Convert.ToInt32(comm3.ExecuteScalar());
            string insertstudent = string.Format("UPDATE [ProjectA].[dbo].[Advisor] SET [Designation]=@regno,[Salary]=@salary WHERE Id = '{0}'", getid);
            SqlCommand comm4 = new SqlCommand(insertstudent, conn);
            comm4.Parameters.AddWithValue("@id", id);
            comm4.Parameters.AddWithValue("@regno", desigval);
            comm4.Parameters.AddWithValue("@salary", txtsalary.Text);
            comm4.ExecuteNonQuery();
            comm4.Parameters.Clear();
            MessageBox.Show("Advisor added");
            data_load();
            conn.Close();
        }

        private void salary_Click(object sender, EventArgs e)
        {

        }

        private void txtsalary_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();
            if (e.ColumnIndex == 9)
            {
                if (MessageBox.Show("Are You Sure to Delete this Record ?", "Student", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;

                    string data = _dgvCurrentRow.Cells[2].Value.ToString();

                    string cmd = string.Format("SELECT Id FROM Person Where Email='{0}'", data);
                    SqlCommand commd = new SqlCommand(cmd, conn);
                    int id = Convert.ToInt32(commd.ExecuteScalar());
                    Console.WriteLine(id);
                    string queryy1 = string.Format("Delete from Advisor where Id='{0}'", id);
                    SqlCommand comd1 = new SqlCommand(queryy1, conn);
                    comd1.ExecuteNonQuery();

                    string queryy = string.Format("Delete from Person where Id = '{0}'", id);
                    SqlCommand comd = new SqlCommand(queryy, conn);
                    comd.ExecuteNonQuery();
                    MessageBox.Show("Advisor deleted");
                    data_load();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                    return;
                }
            }
            else if (e.ColumnIndex == 8)
            {
                DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;
                string data = _dgvCurrentRow.Cells[2].Value.ToString();
                string cmd = string.Format("SELECT Id FROM Person Where Email ='{0}'", data);
                SqlCommand commd = new SqlCommand(cmd, conn);
                getid = Convert.ToInt32(commd.ExecuteScalar());
                txtfirstname.Text = _dgvCurrentRow.Cells[0].Value.ToString();
                txtnum.Text = _dgvCurrentRow.Cells[3].Value.ToString();
                txtlastname.Text = _dgvCurrentRow.Cells[1].Value.ToString();
                txtsalary.Text = _dgvCurrentRow.Cells[7].Value.ToString();
                comboBox1.SelectedValue = Convert.ToInt32(_dgvCurrentRow.Cells[6].ToString());
                cmbgender.Text = _dgvCurrentRow.Cells[5].Value.ToString();
                txtemail.Text = _dgvCurrentRow.Cells[2].Value.ToString();
                dateTimePicker1.Value = Convert.ToDateTime(_dgvCurrentRow.Cells[4].ToString());
                //cmbgender.SelectedValue = Convert.ToInt32(dr["PositionID"].ToString());
                buttonadd.Hide();
                buttonupdate.Show();
                tabPage1.Show();
            }
            else
            {
                conn.Close();
                return;
            }
        }
    }
}
