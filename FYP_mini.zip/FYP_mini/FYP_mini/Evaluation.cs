﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;



namespace FYP_mini
{
    public partial class Evaluation : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DELL-PC\\SABBER;Initial Catalog=ProjectA;Integrated Security=True");
        int getid;
        public Evaluation()
        {
            InitializeComponent();
            buttonupdate.Hide(); 
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            dataGridView1.Refresh();
        }

        private void Evaluation_Load(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToShortDateString();
            label5.Text = DateTime.Now.ToShortDateString();
            conn.Open();
            data_load();
            var EditButton = new DataGridViewButtonColumn();
            EditButton.Name = "EditButton";
            EditButton.HeaderText = "Edit";
            EditButton.Text = "Edit";
            EditButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(EditButton);

            var DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.Name = "DeleteButton";
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Text = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(DeleteButton);

            conn.Close();
        }
        private void data_load()
        {
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT Name,TotalWeightage,TotalMarks FROM [ProjectA].[dbo].[Evaluation]", conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;
        }
        private void buttonadd_Click(object sender, EventArgs e)
        {
            
        }

        private void Evaluation_Click(object sender, EventArgs e)
        {

        }

        private void Evaluation_Shown(object sender, EventArgs e)
        {

        }

        private void buttonadd_Click_1(object sender, EventArgs e)
        {
            conn.Open();


            if (txtname.Text.Trim() == "" && txtmarks.Text.Trim() == "" && txtweightage.Text.Trim() == "")
            {
                MessageBox.Show("All fields are required ");
                conn.Close();
                return;
            }
            

            string insertt = string.Format("INSERT INTO [ProjectA].[dbo].[Evaluation](Name,TotalWeightage,TotalMarks)VALUES (@name,@weightage,@marks)");
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@name", txtname.Text);
            comm2.Parameters.AddWithValue("@weightage", txtweightage.Text);
            comm2.Parameters.AddWithValue("@marks", txtmarks.Text);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            MessageBox.Show("Evaluation information added");
            data_load();
            conn.Close();
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();
            if (e.ColumnIndex == 4)
            {
                if (MessageBox.Show("Are You Sure to Delete this Record ?", "Evaluation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;

                    string data = _dgvCurrentRow.Cells[0].Value.ToString();

                    string cmd = string.Format("SELECT Id FROM Evaluation Where Name ='{0}'", data);
                    SqlCommand commd = new SqlCommand(cmd, conn);
                    int id = Convert.ToInt32(commd.ExecuteScalar());
                    Console.WriteLine(id);
                    string queryy1 = string.Format("Delete from Evaluation where Id='{0}'", id);
                    SqlCommand comd1 = new SqlCommand(queryy1, conn);
                    comd1.ExecuteNonQuery();

                    MessageBox.Show("Data deleted");
                    data_load();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                    return;
                }
            }
            else if (e.ColumnIndex == 3)
            {
                DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;
                string data = _dgvCurrentRow.Cells[0].Value.ToString();
                string cmd = string.Format("SELECT Id FROM Evaluation Where Name ='{0}'", data);
                SqlCommand commd = new SqlCommand(cmd, conn);
                getid = Convert.ToInt32(commd.ExecuteScalar());
                txtname.Text = _dgvCurrentRow.Cells[0].Value.ToString();
                txtmarks.Text = _dgvCurrentRow.Cells[1].Value.ToString();
                txtweightage.Text = _dgvCurrentRow.Cells[2].Value.ToString();
                
                buttonadd.Hide();
                buttonupdate.Show();
                tabPage1.Show();
                conn.Close();
            }
            else
            {
                conn.Close();
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            conn.Open();


            if (txtname.Text.Trim() == "" && txtmarks.Text.Trim() == "" && txtweightage.Text.Trim() == "")
            {
                MessageBox.Show("All fields are required ");
                conn.Close();
                return;
            }

            Console.WriteLine(getid);
            string insertt = string.Format("UPDATE [dbo].[Evaluation] SET Name = @name ,TotalWeightage= @weightage ,TotalMarks=@marks  WHERE Id = '{0}'", getid);
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@name", txtname.Text);
            comm2.Parameters.AddWithValue("@weightage", txtweightage.Text);
            comm2.Parameters.AddWithValue("@marks", txtmarks.Text);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();

            MessageBox.Show("Evaluation information updated");
            data_load();
            tabPage2.Show();
            conn.Close();
        }
    }
}
