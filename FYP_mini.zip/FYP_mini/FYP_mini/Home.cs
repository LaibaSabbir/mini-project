﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FYP_mini
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void student_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Student student = new Student();
            student.Show();
        }

        private void advisor_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Advisor advisor = new Advisor();
            advisor.Show();
        }

        private void evaluation_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Evaluation eval = new Evaluation();
            eval.Show();
        }

        private void project_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Project project = new Project();
            project.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Group grp = new Group();
            grp.Show();
        }

        private void proad_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Project_Advisor proad = new Project_Advisor();
            proad.Show();
        }
    }
}
