﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FYP_mini
{
    public partial class Project_Advisor : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DELL-PC\\SABBER;Initial Catalog=ProjectA;Integrated Security=True");

        public Project_Advisor()
        {
            InitializeComponent();
            string datacmd = "SELECT Value from Lookup WHERE Category='ADVISOR_ROLE' ";
            SqlCommand cmmd = new SqlCommand(datacmd, conn);
            SqlDataAdapter dataadap = new SqlDataAdapter(datacmd, conn);
            DataTable dataset = new DataTable();
            dataadap.Fill(dataset);

            for (int i = 0; i < dataset.Rows.Count; i++)
            {
                comboBox3.Items.Add(dataset.Rows[i]["Value"]);
            }

            string datacmd1 = "SELECT Title from Project WHERE Project.Id IN (SELECT ProjectId  FROM GroupProject) ";
            SqlCommand cmmd1 = new SqlCommand(datacmd1, conn);
            SqlDataAdapter dataadap1 = new SqlDataAdapter(datacmd1, conn);
            DataTable dataset1 = new DataTable();
            dataadap1.Fill(dataset1);

            for (int i = 0; i < dataset1.Rows.Count; i++)
            {
                comboBox2.Items.Add(dataset1.Rows[i]["Title"]);
            }

            string datacmd2 = "SELECT FirstName from Person WHERE Person.Id IN (SELECT Id  FROM Advisor) ";
            SqlCommand cmmd2 = new SqlCommand(datacmd2, conn);
            SqlDataAdapter dataadap2 = new SqlDataAdapter(datacmd2, conn);
            DataTable dataset2 = new DataTable();
            dataadap2.Fill(dataset2);

            for (int i = 0; i < dataset2.Rows.Count; i++)
            {
                comboBox1.Items.Add(dataset2.Rows[i]["Title"]);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            Home home = new Home();
            home.Show();
        }

        private void Project_Advisor_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToShortDateString();
            label2.Text = DateTime.Now.ToShortDateString();
            conn.Open();
            data_load();
            var EditButton = new DataGridViewButtonColumn();
            EditButton.Name = "EditButton";
            EditButton.HeaderText = "Edit";
            EditButton.Text = "Edit";
            EditButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(EditButton);

            var DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.Name = "DeleteButton";
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Text = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            this.dataGridView1.Columns.Add(DeleteButton);

            conn.Close();

        }

        private void data_load()
        {
            SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT AdvisorId,ProjectId,AdvisorRole,AssignmentDate FROM ([ProjectA].[dbo].[ProjectAdvisor] ", conn);
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dtbl;
        }

        private void labelname_Click(object sender, EventArgs e)
        {

        }

        private void buttonadd_Click(object sender, EventArgs e)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            string Stat;
            Stat = string.Format("SELECT Id FROM Lookup WHERE Category='ADVISOR_ROLE' AND Value='{0}'", comboBox3.Text);
            SqlCommand comm1 = new SqlCommand(Stat, conn);
            int statusval = Convert.ToInt32(comm1.ExecuteScalar());

            string stid;
            stid = string.Format("SELECT Id FROM Project WHERE Title='{0}'", comboBox2.Text);
            SqlCommand commd2 = new SqlCommand(stid, conn);
            int stuid = Convert.ToInt32(commd2.ExecuteScalar());

            string stid1;
            stid1 = string.Format("SELECT Id FROM Person WHERE FirstName='{0}'", comboBox1.Text);
            SqlCommand commd21 = new SqlCommand(stid1, conn);
            int stuid1 = Convert.ToInt32(commd21.ExecuteScalar());
            DateTime daate = DateTime.Now.Date;
            string insertt = string.Format("INSERT INTO [ProjectA].[dbo].[ProjectAdvisor](ProjectId,AdvisorRole,AssignmentDate,AdvisorId)VALUES (@Firstname,@Lastname,@daate,@id)");
            SqlCommand comm2 = new SqlCommand(insertt, conn);
            comm2.Parameters.AddWithValue("@Firstname", stuid);
            comm2.Parameters.AddWithValue("@Lastname", statusval);
            comm2.Parameters.AddWithValue("@daate", daate);
            comm2.Parameters.AddWithValue("@id", stuid1);
            comm2.ExecuteNonQuery();
            comm2.Parameters.Clear();


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            conn.Open();
            if (e.ColumnIndex == 4)
            {
                if (MessageBox.Show("Are You Sure to Delete this Record ?", "Project", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataGridViewRow _dgvCurrentRow = dataGridView1.CurrentRow;

                    string data = _dgvCurrentRow.Cells[1].Value.ToString();

                    string cmd = string.Format("SELECT ProjectId FROM GroupStudent Where ProjectId ='{0}'", data);
                    SqlCommand commd = new SqlCommand(cmd, conn);
                    int id = Convert.ToInt32(commd.ExecuteScalar());
                    Console.WriteLine(id);
                    string queryy1 = string.Format("Delete from ProjectAdvisor where ProjectId='{0}'", id);
                    SqlCommand comd1 = new SqlCommand(queryy1, conn);
                    comd1.ExecuteNonQuery();
                    


                    MessageBox.Show("Project deleted");
                    data_load();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                    return;
                }
            }
            else
            {
                conn.Close();
            }
        }
    }
    
}
